from skyfield.api import load, Angle, PlanetaryConstants
from datetime import datetime, timedelta, timezone
from skyfield.positionlib import ICRF
from numpy import arcsin, pi
import math

def main():
	max_eclipse = datetime(2024, 4, 8, 18, 17, 21, tzinfo=timezone.utc)
	
	ephem = load('de441.bsp')
	earth, sun, moon = ephem['earth'], ephem['sun'], ephem['moon']
	
	ts = load.timescale()
	t = ts.from_datetime(max_eclipse)

	dt = (datetime.strptime(t.tt_strftime(), "%Y-%m-%d %H:%M:%S TT") - datetime.strptime(t.ut1_strftime(), "%Y-%m-%d %H:%M:%S UT1")).total_seconds()
		
	observe_moon = earth.at(t).observe(moon)
	observe_sun = earth.at(t).observe(sun)

	print("Info:")
		
	print("Ephemerides: JPL DE441")
	print("Library: Python Skyfield")

	print('TT date and time: ', t.tt_strftime())
	print('TAI date and time:', t.tai_strftime())
	print('UTC date and time:', t.utc_strftime())
	print('UT1 date and time:', t.ut1_strftime())
	print('TDB date and time:', t.tdb_strftime())
	
	print("Delta T:", dt)
	
	print(" ")
	print("Data:")

	sra, sdec, _ = observe_sun.radec()

	mra, mdec, _ = observe_moon.radec()

	print("Sun Ra:", sra)
	print("Moon Ra", mra)

	print("Sun Dec:", sdec)
	print("Moon Dec", mdec)

	MOON_RADIUS = 1737.4 # km
	SUN_RADIUS = 695700 # km

	sappdiam = 360 / pi * arcsin(SUN_RADIUS / observe_sun.distance().km)
	ssemdiam = sappdiam/2

	mappdiam = 360 / pi * arcsin(MOON_RADIUS / observe_moon.distance().km)
	msemdiam = mappdiam/2

	print("Semi Diameter of Sun", Angle(degrees=ssemdiam))
	print("Semi Diameter of Moon", Angle(degrees=msemdiam))

	sepdeg = ICRF(observe_moon.apparent().position.au).separation_from(ICRF(observe_sun.apparent().position.au))
	deg = float(sepdeg.degrees)
	
	print("Gamma:", deg)

	print(" ")
	print("Besselian Elements:")
    
if __name__ == '__main__':
	main()
