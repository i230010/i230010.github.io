sun_radius_km = 695700
earth_radius_km = 6378
moon_radius_km = 1737.4