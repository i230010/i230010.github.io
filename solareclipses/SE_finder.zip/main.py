#This Python script is for calculating the Solar Eclipse on a specific timespan

#Import Libraries/Modules
from skyfield.api import load
from datetime import datetime, timedelta, timezone
from skyfield.positionlib import ICRF
import math

#From next file(s)
import _sedetailer 
import _constants

#Main function
def main():
	#Start time
	curtime = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

	#End time
	endtime = datetime(2025, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
	
	#Load Ephemeris
	#Find here: https://ssd.jpl.nasa.gov/ftp/eph/planets/bsp/
	planets = load('de441.bsp')

	#Load three bodies: Earth, Sun, Moon
	earth, sun, moon = planets['earth'], planets['sun'], planets['moon']
	
	#Loop Time
	while curtime <= endtime:
		#Load skyfield timescale
		ts = load.timescale()
		t = ts.from_datetime(curtime)
		
		#Find Sun and Moon positions
		observe_moon = earth.at(t).observe(moon).apparent().position.au
		observe_sun = earth.at(t).observe(sun).apparent().position.au
		
		#Find separation between Sun and Moon
		separation_deg_raw = ICRF(observe_moon).separation_from(ICRF(observe_sun))
		separation_deg = float(separation_deg_raw.degrees)
		
		#Find Sun and Moon distance
		_, _, sdist = earth.at(t).observe(sun).radec()
		_, _, mdist = earth.at(t).observe(moon).radec()
		
		#Convert into km
		sdistkm = sdist.km
		mdistkm = mdist.km
		
		#Find expected separation
		expected_separation = float(math.degrees(math.asin((float(_constants.moon_radius_km+_constants.earth_radius_km))/mdistkm) + math.asin((float(_constants.sun_radius_km-_constants.earth_radius_km))/sdistkm)))

		#If current separation is lower than expected separation
		if expected_separation >= separation_deg:
			#Find maximum eclipse (optional separation)
			date, minimum_degrees = _sedetailer.sedetail(curtime - timedelta(hours = 2), curtime + timedelta(hours = 4))

			#Print the date
			print(date.strftime("%Y-%m-%dT%H:%M:%SZ"), minimum_degrees)

			#Move forward by 27 days because an eclipse is next around 28 to 30 days after first eclipse aka double duo
			curtime += timedelta(days = 27)
		
		#If not found, move by two hours (to speed up)
		curtime += timedelta(hours = 2)
    
#Run main function
if __name__ == '__main__':
	main()