#Import Libraries/Modules
from skyfield.api import load
from datetime import datetime, timedelta, timezone
from skyfield.positionlib import ICRF
import math

#From next file
import _sedetailer 

#Main function
def main():
	#Start time
	curtime = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

	#End time
	endtime = datetime(2025, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
	
	#Load Ephemeris
	#Find here: https://ssd.jpl.nasa.gov/ftp/eph/planets/bsp/
	ephem = load('de441.bsp')
	
	#Load three bodies
	earth, sun, moon = ephem['earth'], ephem['sun'], ephem['moon']
	
	#Loop Time
	while curtime <= endtime:
		#Load skyfield timescale
		ts = load.timescale()
		t = ts.from_datetime(curtime)
		
		#Track moon and sun coords
		observe_moon = earth.at(t).observe(moon).apparent().position.au
		observe_sun = earth.at(t).observe(sun).apparent().position.au
		
		#Find separation between sun and moon
		sepdeg = ICRF(observe_moon).separation_from(ICRF(observe_sun))
		deg = float(sepdeg.degrees)
	
		#Distance of sun and moon
		_, _, sdistau = earth.at(t).observe(sun).radec()
		_, _, mdistau = earth.at(t).observe(moon).radec()
		
		#Convert into km
		sdist = sdistau.km
		mdist = mdistau.km
		
		#Find expected separation
		sep = float(math.degrees(math.asin((float(1737.4+6378))/mdist) + math.asin((float(695700-6378))/sdist)))

		#If current separation is lower than expected separation
		if sep >= deg:
			#Find maximum eclipse (optional separation)
			date, _ = _sedetailer.sedetail(curtime - timedelta(hours = 2), curtime + timedelta(hours = 5))

			#Print the date
			print(date.strftime("%Y-%m-%dT%H:%M:%SZ"))

			#Move forward by 27 days because an eclipse is next around 28 to 30 days after first eclipse aka double duo
			curtime += timedelta(days = 27)
		
		#If not found, move by one hour
		curtime += timedelta(hours = 1)
    
#Run main function
if __name__ == '__main__':
	main()
