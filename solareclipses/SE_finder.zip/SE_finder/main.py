from skyfield.api import load
from datetime import datetime, timedelta, timezone
from skyfield.positionlib import ICRF
import math
import _sedetailer

def main():
	curtime = datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
	endtime = datetime(2021, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

	ephem = load('de421.bsp')
	earth, sun, moon = ephem['earth'], ephem['sun'], ephem['moon']
	
	while curtime <= endtime:
		ts = load.timescale()
		t = ts.from_datetime(curtime)
		
		observe_moon = earth.at(t).observe(moon).apparent().position.au
		observe_sun = earth.at(t).observe(sun).apparent().position.au
		
		sepdeg = ICRF(observe_moon).separation_from(ICRF(observe_sun))
		deg = float(sepdeg.degrees)
		
		_, _, sdistau = earth.at(t).observe(sun).radec()
		_, _, mdistau = earth.at(t).observe(moon).radec()
		
		sdist = sdistau.km
		mdist = mdistau.km
		
		sep = float(math.degrees(math.asin((float(1737.4+6378))/mdist) + math.asin((float(695700-6378))/sdist)))

		if sep >= deg:
			print(_sedetailer.sedetail(curtime, curtime + timedelta(hours = 5)))
			curtime += timedelta(days = 27)

		curtime += timedelta(seconds = 1)
    
if __name__ == '__main__':
	main()
