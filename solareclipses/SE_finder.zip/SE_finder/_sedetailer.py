#Import Libraries/Modules
from skyfield.api import load
from datetime import datetime, timedelta, timezone
from skyfield.positionlib import ICRF
import math

#Function of finding the lowest separation of moon and sun
def sedetail(curtime, endtime):
	#Temp data's
	tmpdatap = []
	tmpdatat = []

	#Default Date
	date = datetime(2000, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

	#Load Ephemeris
	#Find here: https://ssd.jpl.nasa.gov/ftp/eph/planets/bsp/
	planets = load('de441.bsp')

	#Load three bodies
	earth, sun, moon = planets['earth'], planets['sun'], planets['moon']

	#Loop Time
	while curtime <= endtime:
		#Load skyfield timescale
		ts = load.timescale()
		t = ts.from_datetime(curtime)
	
		#Track moon and sun coords
		observe_moon = earth.at(t).observe(moon).apparent().position.au
		observe_sun = earth.at(t).observe(sun).apparent().position.au
		
		#Find separation between sun and moon
		sepdeg = ICRF(observe_moon).separation_from(ICRF(observe_sun))
		deg = float(sepdeg.degrees)
		
		#Distance of sun and moon
		_, _, sdistau = earth.at(t).observe(sun).radec()
		_, _, mdistau = earth.at(t).observe(moon).radec()
    
		#Convert into km
		sdist = sdistau.km
		mdist = mdistau.km
		
		#Find expected separation
		sep = float(math.degrees(math.asin((float(1737.4+6378))/mdist) + math.asin((float(695700-6378))/sdist)))

		#If current separation is lower than expected separation
		if sep >= deg:
			#Append the data from the current separation until it is greater than expected separation
			tmpdatap.append(deg)
			tmpdatat.append(curtime)
			#Does this every one second
			curtime += timedelta(seconds = 1)
		
		#If not found, move by one second
		curtime += timedelta(seconds = 1)
    
	#Find the minimum separation
	m = min(tmpdatap)

	#Find the date in the minimum separation data
	for i in tmpdatat:
		#Load skyfield timescale
		ts = load.timescale()
		t = ts.from_datetime(i)
		
		#Track moon and sun coords
		observe_moon = earth.at(t).observe(moon).apparent().position.au
		observe_sun = earth.at(t).observe(sun).apparent().position.au
		
		#Find separation between sun and moon
		sepdeg = ICRF(observe_moon).separation_from(ICRF(observe_sun))
		deg = float(sepdeg.degrees)
		
		#Distance of sun and moon
		_, _, sdistau = earth.at(t).observe(sun).radec()
		_, _, mdistau = earth.at(t).observe(moon).radec()
    	
		#Convert into km
		sdist = sdistau.km
		mdist = mdistau.km
		
		#Find expected separation
		sep = float(math.degrees(math.asin((float(1737.4+6378))/mdist) + math.asin((float(695700-6378))/sdist)))

		#If current separation is lower than expected separation
		if sep >= deg:
			#If current separation is equal to the minimum separation
			if deg == m:
				#The date is putted
				date = i
            
    
	#Returns the date and minimum separation
	return date, m
